<title>Wesley</title>
<meta name="title" content="Wesley">
<meta name="description" content="">
<meta name="author" content="">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap core CSS -->
{{ HTML::style('//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css') }}
{{ HTML::style('//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.css') }}
{{ HTML::style('//vjs.zencdn.net/4.12/video-js.css') }}
{{ HTML::style('css/bootstrap.min.css') }}
{{ HTML::style('css/uploadifive.css') }}
{{ HTML::style('css/lib/intlTelInput.css') }}
{{ HTML::style('css/style.css') }}

{{ HTML::script('js/jquery/jquery-1.9.1.min.js') }}
{{ HTML::script('js/libs/jquery.maskedinput.min.js') }}
{{ HTML::script('js/libs/jquery.validate.min.js') }}
{{ HTML::script('js/libs/jquery.uploadifive.min.js') }}
{{ HTML::script('js/libs/placeholders.min.js') }}
{{ HTML::script('js/libs/intlTelInput.min.js') }}
{{ HTML::script('//vjs.zencdn.net/4.12/video.js') }}
{{ HTML::script('js/libs/jquery.cookie.js') }}
{{ HTML::script('js/wesley/main.js') }}